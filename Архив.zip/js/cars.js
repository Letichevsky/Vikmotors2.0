const btnLinkContacts = document.querySelector("#btnLinkContacts")

// BTN and LINKS
btnLinkContacts.onclick = () => {
    location.href = "./contacts.html";
}