const TG = document.querySelector("#TG");
const WU = document.querySelector("#WU");
const VB = document.querySelector("#YT");
const FB = document.querySelector("#FB");
const VBGL = document.querySelector(".VBGiperLink");

TG.onclick = () => {
  window.open("https://t.me/vikmotors");
};

WU.onclick = () => {
  window.open("https://wa.me/4915758064259");
};
VB.onclick = () => {
  window.open("viber://chat?number=4915758064259");
};

FB.onclick = () => {
  window.open(
    "https://m.facebook.com/story.php?story_fbid=pfbid0tVPHj3ddoVFHJ7SsSst9wpgFD2VQrA8xP772WtawJ6psWYgxTrUms7VeR6VvyNdal&id=100089877923046"
  );
};
